
import {createRequire as ___nfyCreateRequire} from "module";
import {fileURLToPath as ___nfyFileURLToPath} from "url";
import {dirname as ___nfyPathDirname} from "path";
let __filename=___nfyFileURLToPath(import.meta.url);
let __dirname=___nfyPathDirname(___nfyFileURLToPath(import.meta.url));
let require=___nfyCreateRequire(import.meta.url);

var __require = /* @__PURE__ */ ((x) => typeof require !== "undefined" ? require : typeof Proxy !== "undefined" ? new Proxy(x, {
  get: (a, b) => (typeof require !== "undefined" ? require : a)[b]
}) : x)(function(x) {
  if (typeof require !== "undefined")
    return require.apply(this, arguments);
  throw Error('Dynamic require of "' + x + '" is not supported');
});

// functions/insert/insert.mjs
var insert_default = async (req, context) => {
  const { createClient } = __require("@supabase/supabase-js");
  const supabaseUrl = "https://jtsqoijulrjlpdmpugnz.supabase.co";
  const supabaseKey = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Imp0c3FvaWp1bHJqbHBkbXB1Z256Iiwicm9sZSI6ImFub24iLCJpYXQiOjE2OTgxNzMyNTEsImV4cCI6MjAxMzc0OTI1MX0.K1qIrb9MwClhvfpq9luLQBMwQKXzbdNzojj_WGD69W8";
  const supabase = createClient(supabaseUrl, supabaseKey);
  console.log("Supabase Instance: ", supabase);
  return new Response();
};
export {
  insert_default as default
};
